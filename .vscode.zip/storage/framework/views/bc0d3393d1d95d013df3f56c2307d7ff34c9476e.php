<form action="/login" method="post">
    <?php echo csrf_field(); ?>

    <?php if(session()->has('loginError')): ?>
        <?php echo e(session('loginError')); ?>

    <?php endif; ?>

    <label for="nid">NID</label>
    <input type="text" name="nid" id="nid" required autofocus>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required autofocus>
    <input type="submit" value="Login">
</form><?php /**PATH D:\Document\Materi\Semester 4\Konstruksi Perangkat Lunak\8 (UTS)\penilaian-app\resources\views/login/index.blade.php ENDPATH**/ ?>