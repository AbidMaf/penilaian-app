<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="" class="navbar-brand">SPOT</a>
    </div>
</nav>
<?php $__env->stopSection(); ?><?php /**PATH D:\Document\Materi\Semester 4\Konstruksi Perangkat Lunak\8 (UTS)\penilaian-app\resources\views/components/navbar.blade.php ENDPATH**/ ?>