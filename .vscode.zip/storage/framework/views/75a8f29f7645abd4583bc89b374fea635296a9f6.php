<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a href="" class="navbar-brand">SPOT</a>
        </div>
    </nav>
    <form method="post" class="row justify-content-md-center g-3 needs-validation shadow-sm" action="/updateNilai/<?php echo e($nilai->id_nilai); ?>">
        <?php echo csrf_field(); ?>
        <div class="col">
            <label for="NimNama" class="form-label">Nim-Nama</label>
            <input type="text" class="form-control" id="NimNama" name="npm" value="<?php echo e($nilai->npm); ?> disabled">
        </div>
        <div class="col-6">
            <label for="Ntugas" class="form-label">Nilai Tugas</label>
            <input type="number" class="form-control" id="Ntugas" name="tugas">
        </div>
        <div class="col-6">
            <label for="Nkuis" class="form-label">Nilai Kuis</label>
            <input type="number" class="form-control" id="Nkuis" name="kuis">
        </div>
        <div class="col-6">
            <label for="Nuts" class="form-label">Nilai UTS</label>
            <input type="number" class="form-control" id="Nuts" name="uts">
        </div>
        <div class="col-6">
            <label for="Nuas" class="form-label">Nilai UAS</label>
            <input type="number" class="form-control" id="Nuas" name="uas">
        </div>
        <div class="col mt-3">
            <input type="submit" value="Submit" class="btn btn-primary form-control">
        </div>
    </form>
</body>
</html><?php /**PATH D:\Document\Materi\Semester 4\Konstruksi Perangkat Lunak\8 (UTS)\penilaian-app\resources\views/nilai/update.blade.php ENDPATH**/ ?>